#!/bin/bash -l
# Slurm batch script to run an ASE-NEB calculation with FHI-aims using MPI on multiple nodes

# ---------- Slurm job settings ----------

#SBATCH -J neb-test                        # Job name
#SBATCH -o slurm.o%j                      # Standard output (%j = job ID)
#SBATCH -e slurm.e%                       # Standard error output
#SBATCH --partition=draco-small           # Partition (queue) to submit to
#SBATCH --nodes=3                         # Number of nodes to use
#SBATCH --ntasks-per-node=32              # MPI tasks per node (adjust to match available cores)
#SBATCH --hint=nomultithread              # Use only physical cores (disable hyperthreading)
#SBATCH --time=00:10:00                   # Walltime limit (HH:MM:SS)
#SBATCH --mail-type=begin,end             # Email notifications for job start and end
#SBATCH -D ./                             # Set working directory for the job

# ---------- Module and environment setup ----------

# Load MPSD-specific module environment
mpsd-modules 25a native

# Load required compilers and libraries
module load gcc/13.2.0
module load cmake/3.27.9 openmpi/4.1.6
module load netlib-scalapack/2.2.0
module load miniforge3
source activate python-3.12             # Activate Python environment with ASE installed

# Store current working directory
WD="$(pwd)"

# ---------- FHI-aims environment setup ----------

# Add required libraries to LD_LIBRARY_PATH (needed for linking ScaLAPACK, OpenMPI, etc.)
export LD_LIBRARY_PATH=/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/openmpi-4.1.6-qdbs55hkbrhswsnkcscidaax4yioesd4/lib:/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/netlib-scalapack-2.2.0-z6aceofd7ghhtj4wyuatf2lefv7vnns5/lib:/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/openblas-0.3.24-wfwv75lmxqjywvujauxkuv76od7cd3le/lib:$LD_LIBRARY_PATH

# Allow large stack sizes for large NEB systems
ulimit -s unlimited

# ---------- NEB setup parameters ----------

# Path to FHI-aims species_defaults directory
SPECIES_DIR="/home/castrojo/FHIaims/species_defaults/defaults_2020/light"

# FHI-aims executable to be launched via srun
AIMS_CMD="/home/castrojo/FHIaims/build/aims.250403.scalapack.mpi.x < /dev/null > aims.out"

# Command to launch a single FHI-aims calculation for an interior NEB image
# Here, 24 MPI tasks per image are requested
CMD="srun --exclusive --exact -n 24 ${AIMS_CMD}"

# Command to launch FHI-aims for the fixed reactant and product images (one after the other)
OUTER_CMD="srun --exclusive  ${AIMS_CMD}"

# Total run time per job stage (in seconds); default is 4 hours
TIME=$(( 4*3600 - 60 )) 

# ---------- Launch NEB run ----------

# This command initializes and runs the NEB calculation
# -n 4      → number of interior NEB images
# --cmd     → command to run for each image
# --outer   → command for reactant/product (only run once)
# --round-robin → distribute images across nodes in a round-robin fashion
python ase_neb ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
    -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time ${TIME} --round-robin &> log.txt

# ---------- (Optional) Restart a previous NEB run from a checkpoint ----------

# If your job stops before convergence, you can restart it from a saved checkpoint file.
# Make sure the filename matches the one saved by ase_neb during the previous run.
# Replace 'XXXX' with the appropriate identifier (e.g. step number or timestamp).
#
# python ase_neb ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
#     --restart=neb_checkpoint_XXXX.traj -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time=${TIME} &> log.txt


#!/usr/bin/env python
# -*-coding:utf-8 -*-
'''
@File    :   ase_neb.py
@Author  :   George Trenins
@Contact :   gstrenin@gmail.com
@Desc    :   Perform a nudged elastic band optimization with ASE using FHI-aims for ab initio force calculations
'''

from __future__ import print_function, division, absolute_import
import argparse
import socket
import sys
from contextlib import closing
from typing import Optional
from pathlib import Path
from ase.mep import NEB
from ase import Atoms
from ase.io import read
from ase.io import write
from ase.constraints import FixAtoms
from ase.io.trajectory import Trajectory
import signal
import time
import os
from ase.calculators.socketio import SocketIOCalculator
import re 
import datetime
from ase.io import write as ase_write

_energy_pattern = re.compile(
    r"Total energy of the DFT / Hartree-Fock s\.c\.f\. calculation\s*:\s*(-?\d+\.\d+)\s*eV"
)

def parse_aims_energy(path):
    """Scan aims.out from bottom up for the SCF total energy."""
    with open(path) as f:
        for line in reversed(f.readlines()):
            m = _energy_pattern.search(line)
            if m:
                return float(m.group(1))
    raise RuntimeError(f"No energy line found in {path}")

class TimeoutException(Exception):
    pass


def timeout_handler(signum, frame):
    raise TimeoutException("Computation timed out.")


def check_socket(host, port):
    """Check if socket is able to bind

    Args:
        host (str): string to the host
        port (int): port for the socket

    Returns:
        bool: True if socket is able to bind
    """

    try:
        socket.getservbyport(port)
        return False
    except OSError:
        pass

    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
        try:
            sock.bind((host, port))
        except OSError:
            return False
    return True


def get_free_port(host, offset=0, port_start=1024):
    """Automatically select a free port to use

    Args:
        host (str): String to the host path
        offset (int): Select the next + offset free port (in case multiple sequntial runs)
        port_start (int): First port to check (must be between 1024 and 49151 Values of the registered ports)

    Returns
        port (int): The available port
    """

    pp = 0
    for ii in range(48127):
        port = 1024 + (port_start - 1024 + ii) % 48127
        if check_socket(host, port):
            pp += 1
        if pp > offset:
            return port
    raise ValueError("No available port found.")


def get_port(host="localhost", port=1024, offset=0):
    """Get the port to use for the socketio calculation

    Args:
        host (str): String to the host path
        port (int): Requested port
        offset (int): Select the next + offset free port (in case multiple sequential runs)

    Returns
        port (int): A free port based on the requested value
    """
    # If a unixsocket is being used then disregard since ports aren't used
    if "UNIX" in host:
        return 1024

    # If automatic find a free port, if port is not free get a new port
    if offset > 0:
        port = get_free_port(host, offset, port)
    elif not check_socket(host, port):
        print(f"Warning: Port {port} in use, changing to the next free port")
        port = get_free_port(host, offset, port)

    return port


def write_launcher(filepath: Path, cmd: str, extra: Optional[str] = None) -> None:
    import stat
    if extra is not None:
        cmd_lst: list[str] = cmd.split()
        cmd_lst.insert(1, extra)
        cmd: str = ' '.join(cmd_lst)

    with open(filepath, 'w') as f:
        f.write(f"#!/bin/bash\n\n{cmd}\n")

    # Get current permissions
    mode = filepath.stat().st_mode

    # Add execute permission for user, group, and others
    filepath.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    return


def create_neb_band(initial: str, final: str, n: int, freeze_indices=None, **kwargs) -> NEB:
    initial: Atoms = read(initial, format="aims")
    final: Atoms = read(final, format="aims")
    # Force same cell and PBC
    final.set_cell(initial.get_cell())
    final.set_pbc(initial.get_pbc())
        
    # New: Freeze atoms if needed. Pass  the indices of the atoms to be frozen in the neb.json file
    if freeze_indices is not None:
        constraint = FixAtoms(indices=freeze_indices)
        initial.set_constraint(constraint)
        final.set_constraint(constraint)

    configs: list[Atoms] = [initial] + [initial.copy() for i in range(n)] + [final]
    band: NEB = NEB(configs, parallel=True, allow_shared_calculator=False,climb=False, **kwargs)
    band.interpolate(method='linear', apply_constraint=True)
    return band


def read_neb_from_restart(restart: str, n: int, freeze_indices=None, **kwargs) -> NEB:
    # open the full checkpoint trajectory
    traj = Trajectory(restart)
    Nframes = len(traj)                # total frames written so far
    needed = n + 2                     # endpoints + n intermediates
    # read only the last `needed` frames
    indices = range(max(0, Nframes - needed), Nframes)
    configs = [traj[i].copy() for i in indices]

    # re‐apply any FixAtoms constraint
    if freeze_indices is not None:
        constraint = FixAtoms(indices=freeze_indices)
        for cfg in configs:
            cfg.set_constraint(constraint)

    band = NEB(configs, parallel=True, climb=False,  allow_shared_calculator=False, **kwargs)
    return band


def main(args: argparse.Namespace) -> None:
    import os
    import subprocess
    import json
    from ase.optimize.optimize import Optimizer, DEFAULT_MAX_STEPS
    from ase import optimize
    from pathlib import Path
    from ase.calculators.aims import Aims, AimsProfile
    from ase.calculators.socketio import SocketIOCalculator
    from itertools import cycle

    wd = Path().cwd()

    # load NEB arguments
    if args.neb is None:
        neb_kwargs = dict()
    else:
        with open(args.neb, 'r') as f:
            neb_kwargs = json.load(f)
    
    freeze_indices = neb_kwargs.pop("freeze_indices", None)    

    # load aims arguments
    with open(args.aims, 'r') as f:
        aims_kwargs = json.load(f)

    # load optimizer arguments
    if args.opt is None:
        opt_kwargs = dict()
    else:
        with open(args.opt, "r") as f:
            opt_kwargs: dict = json.load(f)
    print("neb_kwargs before create_neb_band:", neb_kwargs)

    checkpoint_file = args.restart
    
    if checkpoint_file is not None:
        print(f"Restarting NEB optimization from checkpoint: '{checkpoint_file}'")
        band = read_neb_from_restart(checkpoint_file, args.n, freeze_indices=freeze_indices, **neb_kwargs)
    else:
        print("Starting fresh NEB optimization from initial and final states.")
        band = create_neb_band(args.r, args.p, args.n, freeze_indices=freeze_indices, **neb_kwargs)

    # Write initial NEB trajectory
    write("initial_neb.traj", band.images)
        
    nodelist = os.environ.get('SLURM_JOB_NODELIST', None)
    if nodelist is None:
        assert not args.round_robin, "Cannot read node list, round-robin resource allocation no possible"
        nodes = None
        driver_host = "localhost"
    else:
        nodes = subprocess.check_output(
            ['scontrol', 'show', 'hostnames', nodelist],
            text=True
        ).split()
        driver_host = nodes[0]

    # Set the signal handler and a timeout (in seconds)
    signal.signal(signal.SIGALRM, timeout_handler)
    signal.alarm(args.time) 

    for i in [0, args.n+1]:
        image: Atoms = band.images[i]
        try:
            image.get_potential_energy()
        except Exception:
            pass
        else:
            # Do not recompute the energy if already cached
            continue
        target: Path = Path(f"image{i:02d}")
        port = get_port(host = driver_host)
        cmd = args.outer if args.outer is not None else args.cmd
        launcher = wd / f"_launcher{i:02d}.sh"
        write_launcher(launcher, cmd)
        profile = AimsProfile(str(launcher))
        aims = Aims(
            profile=profile,
            directory=target,
            species_dir=args.species,
            use_pimd_wrapper=(driver_host, port),
            **aims_kwargs
        )
        # Compute the energies and forces on the exterior images: done once
        with SocketIOCalculator(aims, log=sys.stdout, port=port) as calc:
            image.calc = calc
            image.get_forces()

    calcs = []
    if nodes is not None:
        node_cycle = cycle(nodes)
    for i,image in enumerate(band.images[:-1]):
        if i == 0:
            continue
        target: Path = Path(f"image{i:02d}")
        launcher = wd / f"_launcher{i:02d}.sh"
        port = get_port(host = driver_host)
        cmd = args.cmd
        if args.round_robin:
            node = next(node_cycle)
            write_launcher(launcher, cmd, extra=f"--nodelist={node}")
        else:
            write_launcher(launcher, cmd)
        profile = AimsProfile(str(launcher))
        aims = Aims(
            profile=profile,
            directory=target,
            species_dir=args.species,
            compute_forces=True,
            use_pimd_wrapper=(driver_host, port),
            **aims_kwargs
        )
        calc = SocketIOCalculator(calc=aims, port=port, log=sys.stdout)
        # TODO: take care with minimize_rotations_and_translations...
        calc.server = calc.launch_server()
        proc = calc.launch_client(image, properties=["energy", "forces"],
                                  port=calc._port,
                                  unixsocket=calc._unixsocket)
        calc.server.proc = proc 
        calcs.append(calc)
        image.calc = calc

    opt_name = opt_kwargs.pop("optimizer", "FIRE")
    fmax = opt_kwargs.pop("fmax", 0.05)
    steps = opt_kwargs.pop("steps", DEFAULT_MAX_STEPS)

    relax: Optimizer = getattr(optimize, opt_name)(band, **opt_kwargs)
    
    # Attach checkpointing
    def write_timestamped_checkpoint():
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"neb_checkpoint_{ts}.traj"
        ase_write(filename, band.images)     # overwrites any existing file of the same name
        print(f"[CHECKPOINT] Wrote {len(band.images)} images to {filename}")

    relax.attach(write_timestamped_checkpoint, interval=1)
    
    try:
        print(f"Running NEB optimization with {len(band.images)} images and {len(calcs)} calculators.")
        relax.run(fmax=fmax, steps=steps)
        print("NEB optimization completed successfully.")
        signal.alarm(0)
    except TimeoutException:
        print(f"Calculation exceeded the allocated time of {args.time} s, trying to exit gracefully.")
        raise
    finally:
        for calc in calcs:
            calc: SocketIOCalculator
            calc.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("species", help="Path to basis set defaults")
    parser.add_argument("--neb", default=None, help="JSON file specifying the keyword arguments passed to ase.mep.neb.NEB")
    parser.add_argument("--aims", required=True, help="JSON with arguments for ase.calculators.aims.Aims")
    parser.add_argument("--opt", default=None, help='JSON with arguments passed to the optimizer class. The class name should be specified under "optimizer" (default "FIRE"), along with the convergence criterion ("fmax", default 0.05) and maximum number of steps ("steps", default 10^8).')
    parser.add_argument("-n", type=int, default=8, help="number of intermediate images")
    parser.add_argument("-r", default="reactant.in", help="reactant geometry")
    parser.add_argument("-p", default="product.in", help="product geometry")
    parser.add_argument("--restart", default=None, help="Name of .traj file for restarting an NEB optimization. If supplied, the '-r' and '-p' arguments are ignored.")
    parser.add_argument("--cmd", required=True, help="Launcher command for the interior images.")
    parser.add_argument("--outer", default=None, help="Launcher command for the outer images, if different from the configuration files.")
    parser.add_argument("--time", type=int, default=3600, help="calculation time in seconds")
    parser.add_argument("--round-robin", action="store_true", help="Force round-robin resource allocation (assumes SLURM manager).")
    args = parser.parse_args()
    main(args)

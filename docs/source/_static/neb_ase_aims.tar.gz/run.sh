#!/bin/bash -l
#SBATCH -J neb-test
#SBATCH -o slurm.o%j           
#SBATCH -e slurm.e%j           
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=72
#SBATCH --time=04:00:00
#SBATCH --mail-type=begin,end
#SBATCH --mail-user=george.trenins@mpsd.mpg.de
#SBATCH -D ./

module purge
module load intel/2025.0 
module load impi/2021.14 
module load mkl/2025.0
module load python-waterboa/2024.06
WD="$(pwd)"
# virtual environment, loads ase-3.25.0
source "${HOME}/envs/ase-boa/bin/activate"
# custom scripts: puts "ase-neb -> ase_neb.py" into the system path
GTLIB_ROOT="${HOME}/software/gtlib"
export PATH="${GTLIB_ROOT}/bin:${PATH}"
export PYTHONPATH="${GTLIB_ROOT}:${PYTHONPATH}"
# FHI-aims stuff
export LD_LIBRARY_PATH="${INTEL_HOME}/compilers_and_libraries/linux/lib/intel64:${MKL_HOME}/lib/intel64/:${HOME}/.local/lib:${LD_LIBRARY_PATH}"
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export MKL_DYNAMIC=FALSE
ulimit -s unlimited

SPECIES_DIR="/ada/ptmp/mpsd/getren/Electrochemical_PCET/calculations/local/pt111/slab/basissets/light"
VERSION=250403
AIMS_CMD="${HOME}/software/FHIaims/build_${VERSION}/aims.${VERSION}.scalapack.mpi.x < /dev/null > aims.out"
CMD="srun --exclusive --exact -N 1 -n 36 ${AIMS_CMD}"
OUTER_CMD="srun --exclusive --exact ${AIMS_CMD}"
TIME=$(( 4*3600 - 60 ))

# INITIAL
ase-neb ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
    -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time ${TIME} &> log.txt

## RESTART
#ase-neb ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
#    --restart=neb.traj -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time=${TIME} &> log.txt

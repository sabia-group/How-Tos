#!/bin/bash -l
# Example script for local MPSD cluster 
#SBATCH -J neb-test
#SBATCH -o slurm.o%j
#SBATCH -e slurm.e%j
#SBATCH --partition=draco-small
#SBATCH --nodes=3
#SBATCH --ntasks-per-node=32
#SBATCH --hint=nomultithread
#SBATCH --time=00:10:00
#SBATCH -D ./                             

mpsd-modules 25a native
module load gcc/13.2.0
module load cmake/3.27.9 openmpi/4.1.6
module load netlib-scalapack/2.2.0
module load miniforge3
source activate python-3.12             # Activate Python environment with ASE installed

# Store current working directory
WD="$(pwd)"

export LD_LIBRARY_PATH=/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/openmpi-4.1.6-qdbs55hkbrhswsnkcscidaax4yioesd4/lib:/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/netlib-scalapack-2.2.0-z6aceofd7ghhtj4wyuatf2lefv7vnns5/lib:/opt_mpsd/linux-debian12/25a/sandybridge/spack/opt/spack/linux-debian12-sandybridge/gcc-13.2.0/openblas-0.3.24-wfwv75lmxqjywvujauxkuv76od7cd3le/lib:$LD_LIBRARY_PATH

# Allow large stack sizes for large NEB systems
ulimit -s unlimited
SPECIES_DIR="${HOME}/FHIaims/species_defaults/defaults_2020/light"
AIMS_CMD="${HOME}/FHIaims/build/aims.250403.scalapack.mpi.x < /dev/null > aims.out"
# Command to launch a single FHI-aims calculation for an interior NEB image
CMD="srun --exclusive --exact -n 24 ${AIMS_CMD}"
# Command to launch FHI-aims for the fixed reactant and product images (one after the other)
OUTER_CMD="srun --exclusive  ${AIMS_CMD}"
# Total run time per job stage (in seconds); default is 4 hours
TIME=$(( 4*3600 - 60 )) 
# ---------- Launch NEB run ----------

# This command initializes and runs the NEB calculation
python ase_neb.py ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
    -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time ${TIME} --round-robin &> log.txt

# ---------- (Optional) Restart a previous NEB run from a checkpoint ----------

# If your job stops before convergence, you can restart it from a saved checkpoint file.
# Make sure the filename matches the one saved by ase_neb.py during the previous run.
# Replace 'XXXX' with the appropriate identifier (e.g. step number or timestamp).
#
# python ase_neb ${SPECIES_DIR} --neb=neb.json --aims=aims.json --opt=opt.json \
#     --restart=neb_checkpoint_XXXX.traj -n 4 --cmd="${CMD}" --outer="${OUTER_CMD}" --time=${TIME} &> log.txt

